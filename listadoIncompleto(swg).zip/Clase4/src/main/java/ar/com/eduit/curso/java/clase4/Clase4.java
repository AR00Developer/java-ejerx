package ar.com.eduit.curso.java.clase4;
import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
public class Clase4 {
    public static void main(String[] args) {
        //Clase 4 Serialización de Objetos
        String file="datos.dat";
        //Serializado de Objetos
        try(ObjectOutputStream out=new ObjectOutputStream(new FileOutputStream(file))){
            out.writeObject(new Persona("Laura","Casas",32));
            out.writeObject(new Persona("Geronimo","Salgado",21));
            out.writeObject(new Persona("Lorena","Salinas",45));
            out.writeObject(new Persona("Raul","Lescano",54));
            out.writeObject(new Persona("Morena","Suarez",36));
            out.writeObject(new Persona("Lisandro","Molina",27));
            out.writeObject(new Persona("Ana","Molina",27));
            out.writeObject(new Persona("Laura","Abate",27));
        } catch (Exception e) { e.printStackTrace(); }
        
        //Deserializado de objetos
        List<Persona>lista=new ArrayList();
        try (ObjectInputStream in=new ObjectInputStream(new FileInputStream(file))) {
            try{
                while(true){
                    Persona p=(Persona)in.readObject();
                    System.out.println(p);
                    lista.add(p);
                }
            }catch(EOFException ex){ System.out.println("Fin del archivo."); }
        } catch (Exception e) { e.printStackTrace(); }
        
        
        //Api Stream   JDK 8
        
        // select * from clientes;
        System.out.println("*************************************************");
        lista.forEach(System.out::println);
        
        //select nombre from clientes;
        System.out.println("*************************************************");
        lista.stream().map(Persona::getNombre).forEach(System.out::println);
        
        //select nombre,apellido from clientes;
        System.out.println("*************************************************");
        lista.forEach(item->System.out.println(item.getNombre()+" "+item.getApellido()));
        
        //select * from clientes where edad<30;
        System.out.println("*************************************************");
        lista.stream().filter(p->p.getEdad()<30).forEach(System.out::println);
        
        //select nombre from clientes where edad<30;
        System.out.println("*************************************************");
        lista
                .stream()
                .filter(p->p.getEdad()<30).map(Persona::getNombre)
                .forEach(System.out::println);
        
        //select * from clientes where edad between 30 and 40
        System.out.println("*************************************************");
        lista.stream().filter(p->p.getEdad()>=30 && p.getEdad()<=40).forEach(System.out::println);
        
        //select * from clientes where nombre like 'L%';
        System.out.println("*************************************************");
        lista.stream().filter(p->p.getNombre().startsWith("L")).forEach(System.out::println);
        
        //select * from clientes where nombre = 'laura';
        System.out.println("*************************************************");
        lista.stream().filter(p->p.getNombre().equalsIgnoreCase("laura")).forEach(System.out::println);
        
        //select * from clientes order by edad;
        System.out.println("*************************************************");
        lista.stream().sorted(Comparator.comparingInt(Persona::getEdad)).forEach(System.out::println);
        
        
        //select * from clientes order by edad desc;
        System.out.println("*************************************************");
        lista
                .stream()
                .sorted(Comparator.comparingInt(Persona::getEdad).reversed())
                .forEach(System.out::println);
        
        //select * from clientes where nombre like('l%') order by edad desc;
        System.out.println("*************************************************");
        lista
                .stream()
                .filter(p->p.getNombre().toLowerCase().startsWith("l"))
                .sorted(Comparator.comparingInt(Persona::getEdad).reversed())
                .forEach(System.out::println);
        
        //Interfaz Comparable
        //select * from clientes order by apellido,nombre,edad;
        System.out.println("*************************************************");
        lista.stream().sorted().forEach(System.out::println);
                
        // select apellido, count(*) from clientes group by apellido;
        System.out.println("*************************************************");
        lista.stream().collect(Collectors.groupingBy(
                Persona::getApellido,Collectors.counting()
        )).forEach((k,v)->System.out.println(k+""+v));
        
        
        
    }
}