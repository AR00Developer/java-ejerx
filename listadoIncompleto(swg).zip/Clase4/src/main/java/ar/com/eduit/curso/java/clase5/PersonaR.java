
package ar.com.eduit.curso.java.clase5;

import java.util.ArrayList;
import java.util.List;

public class PersonaR {
    private List<Persona>lista;

    public PersonaR() {
        lista = new ArrayList();
        lista.add(new Persona("Laura","Casas",32));
        lista.add(new Persona("Geronimo","Salgado",21));
        lista.add(new Persona("Lorena","Salinas",45));
        lista.add(new Persona("Raul","Lescano",54));
        lista.add(new Persona("Morena","Suarez",36));
        lista.add(new Persona("Lisandro","Molina",27));
        lista.add(new Persona("Ana","Molina",27));
        lista.add(new Persona("Laura","Abate",27));        
    }
    public void add(Persona p){ lista.add(p);}
    public List<Persona> getAll(){return lista;}
    
}
