package ar.com.eduit.curso.java.clase5;
import java.util.List;
import javax.swing.JTable;


public class tableSW <E>{ 
    public void cargar (JTable tbl, List<E> lista ) { 
    } 
}
