package ar.com.eduit.curso.java.clase5;
import java.lang.reflect.Field;
import java.util.List;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author EducaciónIT
 */
public class TableSW <E> {

    public void cargar (JTable tbl, List<E> lista ) {  
        if(tbl==null) return;
        tbl.setModel(new DefaultTableModel());
        if(tbl==null)return ; 
        tbl.setModel(new DefaultTableModel()); 
        if(lista==null  || lista.isEmpty()) return ; 
        E e = lista.get(0); 
        Field[] campos = e.getClass().getDeclaredFields();  
        for(int a=0; a< campos.length;a++ ) { 
            System.out.println(campos[a].getName()); 
        }
        
        
    } 
    
}
