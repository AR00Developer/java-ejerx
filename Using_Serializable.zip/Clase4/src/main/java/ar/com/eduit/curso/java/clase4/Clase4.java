package ar.com.eduit.curso.java.clase4;

import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;


public class Clase4 { 
    public static void main(String[] args) {
          //Clase 4 Serialización de Objetos 
          String file= "datos.dat"; 
          
          //Serializado de Objetos
          try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(file))){
            out.writeObject(new Persona("Laura1", "Salgado", 32));
            out.writeObject(new Persona("Laura2", "Lopez", 3));
            out.writeObject(new Persona("Laura3", "Redd", 2));
            out.writeObject(new Persona("Laura4", "Stack", 22));
            out.writeObject(new Persona("Laura5", "Better", 14));
            out.writeObject(new Persona("Laura7", "Aufwiedersen", 56));
            out.writeObject(new Persona("Laur8", "Komputer", 48));
        } catch (Exception e) { e.printStackTrace() ;  } 
          
          
          //Desarializado de objetos 
          List <Persona>  lista= new ArrayList();
          try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(file))){                  
              
                try {
                  while(true){
                      Persona p=(Persona)in.readObject(); 
                      System.out.println(p); 
                      lista.add(p);
                  }
                } catch (EOFException e) { System.out.println("Fin del Archivo.");}
                
                
          }catch (Exception e) { e.printStackTrace() ;}
          
          
          //Api Stream JDK 8 
          
          // select * from clients ; 
          System.out.println("*****************************");
          lista.forEach(System.out::println); 
          
          
         //select nombre from cliente; 
         System.out.println("*****************************");
         lista.stream().map(Persona::getNombre).forEach(System.out::println); 
         
         
         //select Apellido, Nombre from cliente; 
         System.out.println("*****************************");
         lista.forEach(item->System.out.println(item.getNombre() + " "+ item.getApellido()) ); 
          
    }
          
          
    
    
}
