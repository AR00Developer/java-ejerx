package ar.com.eduit.curso.java.clase4;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class ServerSerializable { 
    public static void main(String[] args) {
        try (ServerSocket ss=new ServerSocket(8000)){
            while(true){
                
                System.out.println("Esperando conexión del cliente");                 
                try(
                    Socket so = ss.accept(); 
                    ObjectInputStream in = new ObjectInputStream(so.getInputStream());
                    ObjectOutputStream out= new ObjectOutputStream(so.getOutputStream());                    
                 ){  
                        System.out.println("Se conecto"+ so.getInetAddress());
                        try {
                        Persona p=(Persona)in.readObject();
                            System.out.println("Se recibio un objeto");
                            System.out.println(p); 
                            out.writeUTF("Se recibio el objeto"); 
                            
                        } catch (ClassCastException e) {
                        
                            System.out.println("Objeto Incorrecto"); 
                            //Escribe un String
                            out.writeUTF("Objeto Incorrecto");
                        }
                 } catch (ClassCastException e) { System.out.println("Objeto incorrecto.");}
                
            }
        } catch (Exception e)  { e.printStackTrace() ;}
    }
        
    
}
